﻿These unchanged third-party sources are available under Mozilla Public License 2.0.
Each .crate is the exact upstream gzip-compressed tar source archive verified against Cargo.lock.
Extract with: tar -xzf <name-version.crate>
Licenses and copyright headers are retained inside each archive.
See ../rust-dependencies.txt for the full MPL 2.0 text and ../mpl-sources.json for URLs and SHA-256.
These are dependency sources, not user notes or MKnote backups.
